/* This file is auto generated, version 201704080516 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#201704080516 SMP Sat Apr 8 09:17:54 UTC 2017"
#define LINUX_COMPILE_BY "kernel"
#define LINUX_COMPILE_HOST "gloin"
#define LINUX_COMPILER "gcc version 6.2.0 20161005 (Ubuntu 6.2.0-5ubuntu12) "
